const path = require('path')
const fs = require('fs')
const {Telegraf} = require('telegraf')

const bot = new Telegraf(process.env.bot_token)
const gameFile = path.resolve(__dirname, 'dungeonbook.json')
const json = fs.readFileSync(gameFile, 'UTF-8').replace(/^\uFEFF/, '')

bot.start(async (ctx) => {
    console.log("Starting the new story for chat:", ctx.chat.id)
    await ctx.replyWithMarkdown("**Добро пожаловать в подземелье 🏰!**")
    return ctx.replyWithMarkdown("Пришли букву или число следующего шага и я расскажу что там.")
});

bot.on('text', (ctx) => {
    if (json[ctx.message.text.toUpperCase()]) {
        return ctx.reply(json[ctx.message.text.toUpperCase()])
    } else {
        return ctx.reply("Сцена не найдена 🫤. Попробуй другую.")
    }
})

module.exports = {
    bot
}